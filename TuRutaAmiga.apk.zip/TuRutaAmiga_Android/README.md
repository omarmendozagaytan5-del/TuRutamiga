# TuRutaAmiga para Android — V5.1

Proyecto Android Studio que envuelve la versión web V5.1 de TuRutaAmiga en un WebView.

## Incluye
- Mapa Leaflet/OpenStreetMap.
- Búsqueda de lugares en México.
- GPS del teléfono.
- Rutas con OSRM.
- Navegación y voz del dispositivo.
- Interfaz V5.1 integrada en la app.

## Cómo generar el APK
1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice y descargue las dependencias.
3. Ejecuta en un teléfono/emulador para probar.
4. Para un APK de prueba: **Build > Build APK(s)**.
5. Para una versión firmada: **Build > Generate Signed App Bundle / APK**.

## Importante
La app necesita Internet para los mapas, búsqueda y rutas porque V5.1 usa servicios externos (OpenStreetMap/Nominatim/OSRM). La ubicación requiere aceptar el permiso de ubicación de Android.

El botón de instalación PWA de la versión web no es necesario dentro del APK: la propia aplicación Android ya está instalada como app.
