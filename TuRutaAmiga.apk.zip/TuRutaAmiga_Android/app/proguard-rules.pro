# TuRutaAmiga - no custom ProGuard rules required.
